import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:salaryredesign/constants/colors.dart';
import 'package:salaryredesign/functions/navigation_functions.dart';
import 'package:salaryredesign/widgets/CustomTexts.dart';
import 'package:salaryredesign/widgets/appbar.dart';
import 'package:salaryredesign/widgets/buttons.dart';
import 'package:salaryredesign/widgets/custom_widgets.dart';
import 'package:salaryredesign/widgets/customtextfield.dart';
import 'package:salaryredesign/widgets/dropdown.dart';

import '../../constants/image_urls.dart';
import '../../constants/sized_box.dart';
import '../../widgets/avatar.dart';

class Mark_Attendance_Page extends StatefulWidget {
  const Mark_Attendance_Page({Key? key}) : super(key: key);

  @override
  State<Mark_Attendance_Page> createState() => _Mark_Attendance_PageState();
}
bool attendance = true;
bool breaks = false;


class _Mark_Attendance_PageState extends State<Mark_Attendance_Page> {

  TextEditingController name = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MyColors.white,
      appBar: appBar(context: context, title: 'Bank / UPI') ,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              color: Color(0xFFEFEFEF),
              padding: EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: Row(
                      children: [
                        Image.asset(
                          MyImages.map_green, height: 35, width: 35,
                        ),
                        hSizedBox,
                        Expanded(
                            child: ParagraphText(
                            text: '46 stv nagar, 4th cross, east, Nava India Rd, Peelamedu, Coimbatore, Tamil Nadu',
                            fontSize: 12,
                            )
                        )
                      ],
                    ),
                  ),
                  hSizedBox2,
                  RoundEdgedButton(text: 'Refresh', minWidth: 80, height: 30, verticalPadding: 0, horizontalPadding: 0,)
                ],
              ),
            ),
            vSizedBox2,
            Container(
              width: MediaQuery.of(context).size.width,
              // margin: EdgeInsets.symmetric(horizontal: 0),
              height: MediaQuery.of(context).size.height - 120,
              decoration: BoxDecoration(
                color: MyColors.white,
                borderRadius: BorderRadius.circular(4)
              ),
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: MyColors.primaryColor,
                          
                        )
                      ),
                      child: Row(
                        children: [
                          Expanded(
                              child: RoundEdgedButton(
                                text: 'ATTENDANCE',
                                borderRadius: 0,
                                color: attendance?MyColors.primaryColor: MyColors.white,
                                textColor: attendance?MyColors.white: MyColors.black,
                                onTap: (){
                                  setState((){
                                    attendance = true;
                                    breaks = false;
                                  });
                                },
                              )
                          ),
                          Expanded(
                              child: RoundEdgedButton(
                                text: 'BREAK',
                                borderRadius: 0,
                                color: breaks? MyColors.primaryColor: MyColors.white,
                                textColor: breaks? MyColors.white: MyColors.black,
                                onTap: (){
                                  setState((){
                                    attendance = false;
                                    breaks = true;
                                  });
                                },
                              )
                          ),
                        ],
                      ),
                    ),
                  ),
                  vSizedBox4,
                  if(attendance)
                  Column(
                    children: [
                      // vSizedBox2,
                      MainHeadingText(text: '08:54:45 AM', fontSize: 32,),
                      vSizedBox05,
                      ParagraphText(text: 'Monday, Mar 24, 2022',),
                      vSizedBox2,
                      Container(
                        width: 102,
                        child: Chip_Custom(
                          text: 'Not Punched',
                          fontsize: 14,
                          fontfamily: 'medium',
                          background: Color(0xFFEFEFEF),
                          textcolor: MyColors.labelcolor,
                        ),
                      ),
                      vSizedBox4,
                      Container(
                        height: 200,
                        width: 200,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: Color(0xFFD9D9D9)
                        ),
                      ),
                      vSizedBox,
                      GestureDetector(
                        onTap: (){},
                       child: Image.asset(MyImages.camera_turn, height: 24,),
                      ),
                      vSizedBox4,
                      Row(
                        children: [
                          Expanded(
                            child: RoundEdgedButton( 
                                text: 'PUNCH IN',
                              onTap: (){
                                showCustomDialogBox(
                                    context: context,
                                    child: Column(
                                      children: [
                                        vSizedBox,
                                        ParagraphText(text: 'Are you sure?',
                                        color: MyColors.black,
                                          fontFamily: 'bold',
                                        ),
                                        vSizedBox,
                                        CircleAvatarcustom(
                                          image: MyImages.avatr6,
                                        ),
                                        vSizedBox2,
                                        Row(
                                          children: [
                                            Image.asset(
                                              MyImages.time, height: 20, width: 20,
                                            ),
                                            hSizedBox,
                                            Expanded(
                                                child: ParagraphText(
                                                  text: '02 Jan 2022 08:54 AM',
                                                  fontSize: 16,
                                                  color: MyColors.labelcolor,
                                                )
                                            )
                                          ],
                                        ),
                                        vSizedBox,
                                        Row(
                                          children: [
                                            Image.asset(
                                              MyImages.map_green, height: 24, width: 24,
                                            ),
                                            hSizedBox,
                                            Expanded(
                                                child: ParagraphText(
                                                  text: '46 stv nagar, 4th cross, east, Nava India Rd, Peelamedu, Coimbatore, Tamil Nadu',
                                                  fontSize: 16,
                                                  color: MyColors.labelcolor,
                                                )
                                            )
                                          ],
                                        ),
                                        vSizedBox2,
                                        Row(
                                          children: [
                                            Expanded(
                                              child: RoundEdgedButton(
                                                text: 'CANCEL',
                                                color: MyColors.disabledcolor,
                                                textColor: MyColors.black,
                                                height: 40,
                                                onTap: (){
                                                  Navigator.pop(context);
                                                },
                                              ),
                                            ),
                                            hSizedBox,
                                            Expanded(
                                              child: RoundEdgedButton(
                                                text: 'PUNCH IN',
                                                height: 40,
                                                onTap: (){
                                                  Navigator.pop(context);
                                                },
                                              ),
                                            ),
                                          ],
                                        ),
                                        vSizedBox2,
                                      ],
                                    )
                                );
                              },
                            ),
                          ),
                          hSizedBox,
                          Expanded(
                            child: RoundEdgedButton( 
                                text: 'PUNCH OUT',
                                color: MyColors.disabledcolor,
                                textColor: MyColors.black,
                              onTap: (){
                                showCustomDialogBox(
                                    context: context,
                                    child: Column(
                                      children: [
                                        vSizedBox,
                                        ParagraphText(text: 'Are you sure?',
                                          color: MyColors.black,
                                          fontFamily: 'bold',
                                        ),
                                        vSizedBox,
                                        CircleAvatarcustom(
                                          image: MyImages.avatr6,
                                        ),
                                        vSizedBox2,
                                        Row(
                                          children: [
                                            Image.asset(
                                              MyImages.time, height: 20, width: 20,
                                            ),
                                            hSizedBox,
                                            Expanded(
                                                child: ParagraphText(
                                                  text: '02 Jan 2022 08:54 AM',
                                                  fontSize: 16,
                                                  color: MyColors.labelcolor,
                                                )
                                            )
                                          ],
                                        ),
                                        vSizedBox,
                                        Row(
                                          children: [
                                            Image.asset(
                                              MyImages.map_green, height: 24, width: 24,
                                            ),
                                            hSizedBox,
                                            Expanded(
                                                child: ParagraphText(
                                                  text: '46 stv nagar, 4th cross, east, Nava India Rd, Peelamedu, Coimbatore, Tamil Nadu',
                                                  fontSize: 16,
                                                  color: MyColors.labelcolor,
                                                )
                                            )
                                          ],
                                        ),
                                        vSizedBox2,
                                        Row(
                                          children: [
                                            Expanded(
                                              child: RoundEdgedButton(
                                                text: 'CANCEL',
                                                color: MyColors.disabledcolor,
                                                textColor: MyColors.black,
                                                height: 40,
                                                onTap: (){
                                                  Navigator.pop(context);
                                                },
                                              ),
                                            ),
                                            hSizedBox,
                                            Expanded(
                                              child: RoundEdgedButton(
                                                text: 'PUNCH OUT',
                                                height: 40,
                                                onTap: (){
                                                  Navigator.pop(context);
                                                },
                                              ),
                                            ),
                                          ],
                                        ),
                                        vSizedBox2,
                                      ],
                                    )
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                      vSizedBox4,
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              children: [
                                MainHeadingText(
                                  text: '--:--',
                                  fontSize: 24, color: MyColors.primaryColor,
                                ),
                                ParagraphText(text: 'Punch In', fontFamily: 'bold', )
                              ],
                            ),
                            Column(
                              children: [
                                MainHeadingText(
                                  text: '--:--',
                                  fontSize: 24, color: MyColors.primaryColor,
                                ),
                                ParagraphText(text: 'Punch Out', fontFamily: 'bold', )
                              ],
                            ),
                            Column(
                              children: [
                                MainHeadingText(
                                  text: '--:--',
                                  fontSize: 24, color: MyColors.primaryColor,
                                ),
                                ParagraphText(text: 'Working Hrs', fontFamily: 'bold', )
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  if(breaks)
                    Column(
                      children: [
                        // vSizedBox2,
                        MainHeadingText(text: '08:54:45 AM', fontSize: 32,),
                        vSizedBox05,
                        ParagraphText(text: 'Monday, Mar 24, 2022',),
                        vSizedBox2,
                        Container(
                          width: 102,
                          child: Chip_Custom(
                            text: 'Not Punched',
                            fontsize: 14,
                            fontfamily: 'medium',
                            background: Color(0xFFEFEFEF),
                            textcolor: MyColors.labelcolor,
                          ),
                        ),
                        vSizedBox4,
                        Container(
                          height: 200,
                          width: 200,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              color: Color(0xFFD9D9D9)
                          ),
                        ),
                        vSizedBox,
                        GestureDetector(
                          onTap: (){},
                          child: Image.asset(MyImages.camera_turn, height: 24,),
                        ),
                        vSizedBox4,
                        Row(
                          children: [
                            Expanded(
                              child: RoundEdgedButton(
                                text: 'BREAK IN',
                                onTap: (){
                                  showCustomDialogBox(
                                      context: context,
                                      child: Column(
                                        children: [
                                          vSizedBox,
                                          ParagraphText(text: 'Are you sure?',
                                            color: MyColors.black,
                                            fontFamily: 'bold',
                                          ),
                                          vSizedBox,
                                          CircleAvatarcustom(
                                            image: MyImages.avatr6,
                                          ),
                                          vSizedBox2,
                                          Row(
                                            children: [
                                              Image.asset(
                                                MyImages.time, height: 20, width: 20,
                                              ),
                                              hSizedBox,
                                              Expanded(
                                                  child: ParagraphText(
                                                    text: '02 Jan 2022 08:54 AM',
                                                    fontSize: 16,
                                                    color: MyColors.labelcolor,
                                                  )
                                              )
                                            ],
                                          ),
                                          vSizedBox,
                                          Row(
                                            children: [
                                              Image.asset(
                                                MyImages.map_green, height: 24, width: 24,
                                              ),
                                              hSizedBox,
                                              Expanded(
                                                  child: ParagraphText(
                                                    text: '46 stv nagar, 4th cross, east, Nava India Rd, Peelamedu, Coimbatore, Tamil Nadu',
                                                    fontSize: 16,
                                                    color: MyColors.labelcolor,
                                                  )
                                              )
                                            ],
                                          ),
                                          vSizedBox2,
                                          Row(
                                            children: [
                                              Expanded(
                                                child: RoundEdgedButton(
                                                  text: 'CANCEL',
                                                  color: MyColors.disabledcolor,
                                                  textColor: MyColors.black,
                                                  height: 40,
                                                  onTap: (){
                                                    Navigator.pop(context);
                                                  },
                                                ),
                                              ),
                                              hSizedBox,
                                              Expanded(
                                                child: RoundEdgedButton(
                                                  text: 'BREAK IN',
                                                  height: 40,
                                                  onTap: (){
                                                    Navigator.pop(context);
                                                  },
                                                ),
                                              ),
                                            ],
                                          ),
                                          vSizedBox2,
                                        ],
                                      )
                                  );
                                },
                              ),
                            ),
                            hSizedBox,
                            Expanded(
                              child: RoundEdgedButton(
                                text: 'BREAK OUT',
                                color: MyColors.disabledcolor,
                                textColor: MyColors.black,
                                onTap: (){
                                  showCustomDialogBox(
                                      context: context,
                                      child: Column(
                                        children: [
                                          vSizedBox,
                                          ParagraphText(text: 'Are you sure?',
                                            color: MyColors.black,
                                            fontFamily: 'bold',
                                          ),
                                          vSizedBox,
                                          CircleAvatarcustom(
                                            image: MyImages.avatr6,
                                          ),
                                          vSizedBox2,
                                          Row(
                                            children: [
                                              Image.asset(
                                                MyImages.time, height: 20, width: 20,
                                              ),
                                              hSizedBox,
                                              Expanded(
                                                  child: ParagraphText(
                                                    text: '02 Jan 2022 08:54 AM',
                                                    fontSize: 16,
                                                    color: MyColors.labelcolor,
                                                  )
                                              )
                                            ],
                                          ),
                                          vSizedBox,
                                          Row(
                                            children: [
                                              Image.asset(
                                                MyImages.map_green, height: 24, width: 24,
                                              ),
                                              hSizedBox,
                                              Expanded(
                                                  child: ParagraphText(
                                                    text: '46 stv nagar, 4th cross, east, Nava India Rd, Peelamedu, Coimbatore, Tamil Nadu',
                                                    fontSize: 16,
                                                    color: MyColors.labelcolor,
                                                  )
                                              )
                                            ],
                                          ),
                                          vSizedBox2,
                                          Row(
                                            children: [
                                              Expanded(
                                                child: RoundEdgedButton(
                                                  text: 'CANCEL',
                                                  color: MyColors.disabledcolor,
                                                  textColor: MyColors.black,
                                                  height: 40,
                                                  onTap: (){
                                                    Navigator.pop(context);
                                                  },
                                                ),
                                              ),
                                              hSizedBox,
                                              Expanded(
                                                child: RoundEdgedButton(
                                                  text: 'BREAK OUT',
                                                  height: 40,
                                                  onTap: (){
                                                    Navigator.pop(context);
                                                  },
                                                ),
                                              ),
                                            ],
                                          ),
                                          vSizedBox2,
                                        ],
                                      )
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                        vSizedBox4,
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                children: [
                                  MainHeadingText(
                                    text: '--:--',
                                    fontSize: 24, color: MyColors.primaryColor,
                                  ),
                                  ParagraphText(text: 'Break In', fontFamily: 'bold', )
                                ],
                              ),
                              Column(
                                children: [
                                  MainHeadingText(
                                    text: '--:--',
                                    fontSize: 24, color: MyColors.primaryColor,
                                  ),
                                  ParagraphText(text: 'Break Out', fontFamily: 'bold', )
                                ],
                              ),
                              Column(
                                children: [
                                  MainHeadingText(
                                    text: '--:--',
                                    fontSize: 24, color: MyColors.primaryColor,
                                  ),
                                  ParagraphText(text: 'Break Hrs', fontFamily: 'bold', )
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),

                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
